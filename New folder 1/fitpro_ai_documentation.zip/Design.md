# Design for AI Food Scanner & Nutrition Coach App

This document outlines the visual design guidelines for the AI Food Scanner & Nutrition Coach mobile application, covering color palette, typography, and overall theme to ensure a consistent and user-friendly experience.

## 1. Brand Identity & Theme

*   **Theme:** Clean, modern, fresh, and intuitive.
*   **Goal:** To convey health, trustworthiness, and ease of use.

## 2. Color Palette

Our color palette is designed to be inviting, clear, and supportive of a health-focused application. We will use a primary, secondary, accent, and neutral color set.

| Color Name     | Hex Code  | Usage                                        |
| :------------- | :-------- | :------------------------------------------- |
| Primary Green  | `#4CAF50` | Main interactive elements, success states    |
| Secondary Blue | `#2196F3` | Secondary actions, informational elements    |
| Accent Orange  | `#FF9800` | Call-to-action buttons, warnings             |
| Dark Gray      | `#424242` | Headings, primary text                       |
| Medium Gray    | `#757575` | Secondary text, icons                        |
| Light Gray     | `#E0E0E0` | Borders, backgrounds, disabled states        |
| White          | `#FFFFFF` | Backgrounds, text on dark elements           |

## 3. Typography

We will use a sans-serif typeface for its readability and modern aesthetic, suitable for both headings and body text across various screen sizes.

*   **Primary Font:** Montserrat (or similar Google Font if Montserrat is not available/suitable for licensing)
    *   **Usage:** Headings, prominent text, call-to-actions.
    *   **Weights:** Bold (700), Semi-Bold (600), Medium (500).
*   **Secondary Font:** Open Sans (or similar Google Font)
    *   **Usage:** Body text, labels, captions, detailed nutritional information.
    *   **Weights:** Regular (400), Semi-Bold (600).

### Font Sizing (Example for Mobile)

| Element          | Font Size (px) | Weight    |
| :--------------- | :------------- | :-------- |
| H1 (Screen Title)| 28             | Montserrat Bold |
| H2 (Section Title)| 22             | Montserrat Semi-Bold |
| Body Text Large  | 16             | Open Sans Regular |
| Body Text Medium | 14             | Open Sans Regular |
| Caption/Small    | 12             | Open Sans Regular |

## 4. Iconography

*   **Style:** Line icons, consistent and minimalist.
*   **Source:** Material Design Icons or a custom icon set.

## 5. Imagery & Illustrations

*   **Style:** Clean, realistic food photography for scanned items. Simple, friendly illustrations for onboarding and empty states.
*   **Tone:** Positive, encouraging, and informative.

## 6. UI Components (General Guidelines)

*   **Buttons:** Rounded corners, clear states (default, pressed, disabled).
*   **Input Fields:** Clearly defined borders, placeholder text, and validation feedback.
*   **Cards:** Used for displaying nutritional information and meal logs, with subtle shadows for depth.
*   **Navigation:** Intuitive bottom tab navigation for primary sections, clear header for secondary navigation.

## 7. Accessibility

*   Ensure sufficient color contrast for all text and interactive elements.
*   Provide clear focus states for interactive elements.
*   Support dynamic type sizing for users with visual impairments.
*   Implement proper semantic structuring for screen readers.
