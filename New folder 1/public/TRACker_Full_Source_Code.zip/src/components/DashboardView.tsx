import React from 'react';
import { useAppStore, formatInr } from '../store/useAppStore';
import {
  Flame, Target, Camera, Trash2, Droplets,
  Utensils, ChevronRight, TrendingUp, Zap, Apple, CheckCircle2
} from 'lucide-react';

interface Props { onOpenWizard: () => void; }

export const DashboardView: React.FC<Props> = ({ onOpenWizard }) => {
  const {
    userProfile, macroGoals, loggedMeals, removeLoggedMeal,
    setActiveTab, waterIntakeLiters, addWater, setWater, setWaterGoal, isDarkMode: dark
  } = useAppStore();

  const [isEditingWater, setIsEditingWater] = React.useState(false);
  const [waterInputValue, setWaterInputValue] = React.useState(String(waterIntakeLiters));
  const [waterGoalInputValue, setWaterGoalInputValue] = React.useState(String(macroGoals.waterLiters));

  const handleSaveWaterInput = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedCurrent = parseFloat(waterInputValue);
    const parsedGoal = parseFloat(waterGoalInputValue);

    if (!isNaN(parsedCurrent) && parsedCurrent >= 0) {
      setWater(parsedCurrent);
    }
    if (!isNaN(parsedGoal) && parsedGoal > 0) {
      setWaterGoal(parsedGoal);
    }
    setIsEditingWater(false);
  };

  // ── Computed Totals ──────────────────────────────────────────────────────
  const totalCal = loggedMeals.reduce((s, m) => s + m.foodItem.calories * m.servings, 0);
  const totalPro = loggedMeals.reduce((s, m) => s + m.foodItem.protein * m.servings, 0);
  const totalCarbs = loggedMeals.reduce((s, m) => s + m.foodItem.carbs * m.servings, 0);
  const totalFat = loggedMeals.reduce((s, m) => s + m.foodItem.fat * m.servings, 0);
  const totalSpend = loggedMeals.reduce((s, m) => s + (m.foodItem.priceInr ?? 0) * m.servings, 0);

  const calPct = Math.min(100, Math.round((totalCal / macroGoals.calories) * 100));
  const proPct = Math.min(100, Math.round((totalPro / macroGoals.proteinGrams) * 100));
  const carbsPct = Math.min(100, Math.round((totalCarbs / macroGoals.carbsGrams) * 100));
  const fatPct = Math.min(100, Math.round((totalFat / macroGoals.fatGrams) * 100));
  const waterPct = Math.min(100, Math.round((waterIntakeLiters / macroGoals.waterLiters) * 100));
  const budgetPct = Math.min(100, Math.round((totalSpend / userProfile.dailyBudgetInr) * 100));
  const calsRemaining = Math.max(0, macroGoals.calories - totalCal);

  // ── Theme ────────────────────────────────────────────────────────────────
  const bg = dark ? 'bg-zinc-950' : 'bg-gray-50';
  const card = dark ? 'bg-zinc-900/70 border-zinc-800' : 'bg-white border-gray-200';
  const inner = dark ? 'bg-zinc-800/60' : 'bg-gray-50';
  const txt = dark ? 'text-white' : 'text-gray-900';
  const muted = dark ? 'text-zinc-400' : 'text-gray-500';
  const progress = dark ? 'bg-zinc-800' : 'bg-gray-200';
  const goalBadge = userProfile.goal === 'fat_loss' ? 'bg-red-500/10 text-red-400 border-red-500/20' : userProfile.goal === 'muscle_gain' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

  const macros = [
    { label: 'Protein', val: totalPro, goal: macroGoals.proteinGrams, pct: proPct, color: 'bg-blue-500', tc: 'text-blue-400' },
    { label: 'Carbs', val: totalCarbs, goal: macroGoals.carbsGrams, pct: carbsPct, color: 'bg-amber-400', tc: 'text-amber-400' },
    { label: 'Fats', val: totalFat, goal: macroGoals.fatGrams, pct: fatPct, color: 'bg-emerald-500', tc: 'text-emerald-400' },
  ];

  return (
    <div className={`min-h-screen ${bg} transition-colors duration-200`}>
      <div className="max-w-6xl mx-auto px-4 py-6 space-y-5">

        {/* ── Welcome Banner ─────────────────────────────────────────────────── */}
        <div className={`rounded-2xl border p-5 ${card} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ns-card`}>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-[11px] font-extrabold border px-2.5 py-0.5 rounded-full uppercase tracking-wide font-heading ${goalBadge}`}>
                {userProfile.goal.replace('_', ' ')}
              </span>
              <span className={`text-[11px] font-mono ${muted}`}>TDEE {macroGoals.calories} kcal/day</span>
            </div>
            <h1 className={`text-2xl font-bold font-heading leading-tight ${txt}`}>
              Good day, {userProfile.name.split(' ')[0]} 👋
            </h1>
            <p className={`text-xs mt-0.5 font-body ${muted}`}>
              {totalCal} kcal logged today · {calsRemaining > 0 ? `${calsRemaining} kcal remaining` : '✅ Goal reached!'}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setActiveTab('meals')}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl border text-xs font-bold transition touch-target ${dark ? 'bg-zinc-900 border-zinc-700 text-zinc-200 hover:bg-zinc-800' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
            >
              <Utensils className="w-4 h-4 text-[#2196F3]" /> <span className="font-heading">Meal Planner</span>
            </button>
            <button
              onClick={() => setActiveTab('scanner')}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#4CAF50] hover:bg-[#43A047] text-white text-xs font-bold shadow-nutriscan transition touch-target"
            >
              <Camera className="w-4 h-4" /> <span className="font-heading">Scan Food</span>
            </button>
          </div>
        </div>

        {/* ── Stats Row ─────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Calories', val: `${totalCal}`, sub: `/ ${macroGoals.calories} kcal`, icon: Flame, tc: 'text-orange-400', bg: 'bg-orange-500/10' },
            { label: 'Protein', val: `${totalPro}g`, sub: `/ ${macroGoals.proteinGrams}g goal`, icon: Zap, tc: 'text-blue-400', bg: 'bg-blue-500/10' },
            { label: 'Budget Used', val: formatInr(totalSpend), sub: `/ ${formatInr(userProfile.dailyBudgetInr)} limit`, icon: Target, tc: budgetPct > 100 ? 'text-red-400' : 'text-emerald-400', bg: budgetPct > 100 ? 'bg-red-500/10' : 'bg-emerald-500/10' },
            { label: 'Water', val: `${waterIntakeLiters}L`, sub: `/ ${macroGoals.waterLiters}L target`, icon: Droplets, tc: 'text-cyan-400', bg: 'bg-cyan-500/10' },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className={`rounded-2xl border p-4 ${card}`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${s.bg}`}>
                  <Icon className={`w-4 h-4 ${s.tc}`} />
                </div>
                <div className={`text-lg font-extrabold ${s.tc}`}>{s.val}</div>
                <div className={`text-xs ${muted}`}>{s.label}</div>
                <div className={`text-[10px] font-medium mt-0.5 ${muted}`}>{s.sub}</div>
              </div>
            );
          })}
        </div>

        {/* ── Main Content Grid ─────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">

          {/* Calorie Ring + Macros — LEFT */}
          <div className={`lg:col-span-2 rounded-2xl border p-5 ${card} space-y-4`}>
            <div className="flex items-center justify-between">
              <h2 className={`text-sm font-extrabold ${txt}`}>Daily Energy</h2>
              <span className={`text-xs font-bold ${muted}`}>{calPct}% complete</span>
            </div>

            {/* Calorie Arc */}
            <div className="flex items-center justify-center py-2">
              <div className="relative w-32 h-32">
                <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                  <circle cx="60" cy="60" r="48" fill="none" stroke={dark ? '#27272a' : '#e5e7eb'} strokeWidth="10" />
                  <circle
                    cx="60" cy="60" r="48" fill="none"
                    stroke={calPct >= 90 ? '#22c55e' : '#3b82f6'}
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 48}`}
                    strokeDashoffset={`${2 * Math.PI * 48 * (1 - calPct / 100)}`}
                    className="transition-all duration-700"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-xl font-extrabold leading-none ${txt}`}>{totalCal}</span>
                  <span className={`text-[10px] font-bold ${muted}`}>kcal eaten</span>
                  <span className={`text-[10px] font-medium ${muted}`}>/{macroGoals.calories}</span>
                </div>
              </div>
            </div>

            {/* Macro Bars */}
            <div className="space-y-2.5">
              {macros.map(m => (
                <div key={m.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className={`font-semibold ${muted}`}>{m.label}</span>
                    <span className={`font-bold ${m.tc}`}>{m.val}g / {m.goal}g</span>
                  </div>
                  <div className={`h-1.5 rounded-full ${progress}`}>
                    <div className={`h-1.5 rounded-full transition-all duration-500 ${m.color}`} style={{ width: `${m.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Water / Hydration Section (Editable) */}
            <div className={`pt-3 border-t ${dark ? 'border-zinc-800' : 'border-gray-100'}`}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5">
                  <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                  <span className={`text-xs font-semibold ${muted}`}>Hydration</span>
                </div>

                {isEditingWater ? (
                  <form onSubmit={handleSaveWaterInput} className="flex items-center gap-1.5 flex-wrap">
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-cyan-400 font-bold">Drank:</span>
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        max="20"
                        value={waterInputValue}
                        onChange={(e) => setWaterInputValue(e.target.value)}
                        className={`w-14 px-1 py-0.5 rounded text-xs font-bold border focus:outline-none ${dark ? 'bg-zinc-900 border-cyan-500 text-cyan-400' : 'bg-white border-cyan-400 text-cyan-600'}`}
                        autoFocus
                      />
                      <span className="text-[10px] text-cyan-400 font-bold">L</span>
                    </div>

                    <span className="text-zinc-500 font-bold text-xs">/</span>

                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-cyan-400 font-bold">Target:</span>
                      <input
                        type="number"
                        step="0.1"
                        min="0.5"
                        max="20"
                        value={waterGoalInputValue}
                        onChange={(e) => setWaterGoalInputValue(e.target.value)}
                        className={`w-14 px-1 py-0.5 rounded text-xs font-bold border focus:outline-none ${dark ? 'bg-zinc-900 border-cyan-500 text-cyan-400' : 'bg-white border-cyan-400 text-cyan-600'}`}
                      />
                      <span className="text-[10px] text-cyan-400 font-bold">L</span>
                    </div>

                    <button
                      type="submit"
                      className="px-2 py-0.5 rounded bg-cyan-500 hover:bg-cyan-400 text-zinc-950 text-[10px] font-extrabold"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditingWater(false)}
                      className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[10px] font-bold"
                    >
                      ✕
                    </button>
                  </form>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-cyan-400">{waterIntakeLiters}L / {macroGoals.waterLiters}L</span>
                    <button
                      onClick={() => {
                        setWaterInputValue(String(waterIntakeLiters));
                        setWaterGoalInputValue(String(macroGoals.waterLiters));
                        setIsEditingWater(true);
                      }}
                      className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/30 transition"
                      title="Edit intake amount or target goal"
                    >
                      ✏️ Edit Goal
                    </button>
                  </div>
                )}
              </div>

              <div className={`h-1.5 rounded-full ${progress} mb-2`}>
                <div className="h-1.5 rounded-full bg-cyan-400 transition-all duration-500" style={{ width: `${waterPct}%` }} />
              </div>

              {/* Quick Hydration Buttons */}
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  onClick={() => addWater(-0.25)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${dark ? 'bg-zinc-800/80 text-red-400 hover:bg-zinc-700' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}
                  title="Remove 250ml"
                >
                  -250ml
                </button>
                <button
                  onClick={() => addWater(0.25)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${dark ? 'bg-zinc-800 text-cyan-400 hover:bg-zinc-700' : 'bg-cyan-50 text-cyan-600 hover:bg-cyan-100'}`}
                >
                  +250ml
                </button>
                <button
                  onClick={() => addWater(0.5)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${dark ? 'bg-zinc-800 text-cyan-400 hover:bg-zinc-700' : 'bg-cyan-50 text-cyan-600 hover:bg-cyan-100'}`}
                >
                  +500ml
                </button>
                <button
                  onClick={() => setWater(0)}
                  className={`py-1.5 rounded-lg text-[10px] font-bold transition ${dark ? 'bg-zinc-800/50 text-zinc-400 hover:bg-zinc-700 hover:text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
                  title="Reset daily water counter"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>

          {/* Logged Meals — RIGHT */}
          <div className={`lg:col-span-3 rounded-2xl border ${card} flex flex-col`}>
            <div className={`flex items-center justify-between px-5 pt-5 pb-3 border-b ${dark ? 'border-zinc-800' : 'border-gray-100'}`}>
              <div>
                <h2 className={`text-sm font-extrabold ${txt}`}>Today's Meals</h2>
                <p className={`text-xs ${muted}`}>{loggedMeals.length} items · {formatInr(totalSpend)} of {formatInr(userProfile.dailyBudgetInr)} budget</p>
              </div>
              <button
                onClick={() => setActiveTab('scanner')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition"
              >
                + Add Food
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-2.5 max-h-[400px]">
              {loggedMeals.length === 0 ? (
                <div className={`text-center py-12 ${muted}`}>
                  <Apple className="w-10 h-10 mx-auto mb-3 opacity-30" />
                  <p className="text-sm font-medium">No meals logged yet</p>
                  <p className="text-xs mt-1">Use AI Scanner or Meal Planner to add food</p>
                </div>
              ) : (
                loggedMeals.map(meal => {
                  const mealCal = meal.foodItem.calories * meal.servings;
                  const mealPct = Math.min(100, Math.round((mealCal / macroGoals.calories) * 100));
                  return (
                    <div key={meal.id} className={`flex items-center gap-3 p-3 rounded-xl border transition ${dark ? 'bg-zinc-800/50 border-zinc-700/50 hover:border-zinc-600' : 'bg-gray-50 border-gray-100 hover:border-gray-200'}`}>
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm shrink-0 ${inner}`}>
                        🍽️
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-bold truncate ${txt}`}>{meal.foodItem.name}</p>
                        <p className={`text-[10px] font-medium ${muted}`}>{meal.timestamp} · {meal.mealType}</p>
                        <div className={`h-1 rounded-full mt-1.5 ${progress}`}>
                          <div className="h-1 rounded-full bg-blue-500" style={{ width: `${mealPct}%` }} />
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className={`text-xs font-extrabold ${txt}`}>{mealCal} kcal</div>
                        <div className="text-[10px] text-blue-400 font-medium">{meal.foodItem.protein * meal.servings}g prot</div>
                      </div>
                      <button
                        onClick={() => removeLoggedMeal(meal.id)}
                        className={`p-1.5 rounded-lg transition shrink-0 ${dark ? 'hover:bg-red-900/40 text-zinc-600 hover:text-red-400' : 'hover:bg-red-50 text-gray-400 hover:text-red-400'}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>

            {/* Meal Planner CTA */}
            <div className={`border-t px-5 py-3 ${dark ? 'border-zinc-800' : 'border-gray-100'}`}>
              <button
                onClick={() => setActiveTab('meals')}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border text-xs font-bold transition ${dark ? 'bg-zinc-800/60 border-zinc-700 text-zinc-300 hover:bg-zinc-800' : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'}`}
              >
                <div className="flex items-center gap-2">
                  <Utensils className="w-4 h-4 text-blue-400" />
                  <span>Open Weekly Meal Planner</span>
                </div>
                <ChevronRight className="w-4 h-4 text-zinc-500" />
              </button>
            </div>
          </div>
        </div>

        {/* ── Quick Actions ─────────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            {
              title: 'Scan Food with AI',
              desc: 'Instant nutrition & glycemic analysis',
              icon: Camera,
              color: 'text-blue-400',
              bg: 'bg-blue-500/10',
              border: 'border-blue-500/20',
              action: () => setActiveTab('scanner'),
            },
            {
              title: 'View Analytics',
              desc: 'Trends, macros & weekly breakdown',
              icon: TrendingUp,
              color: 'text-emerald-400',
              bg: 'bg-emerald-500/10',
              border: 'border-emerald-500/20',
              action: () => setActiveTab('analytics'),
            },
            {
              title: 'Edit Profile & Goals',
              desc: 'TDEE, dietary preference, budget',
              icon: Target,
              color: 'text-amber-400',
              bg: 'bg-amber-500/10',
              border: 'border-amber-500/20',
              action: onOpenWizard,
            },
          ].map((a) => {
            const Icon = a.icon;
            return (
              <button
                key={a.title}
                onClick={a.action}
                className={`flex items-center gap-4 p-4 rounded-2xl border transition text-left ${card} hover:${a.border}`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${a.bg}`}>
                  <Icon className={`w-5 h-5 ${a.color}`} />
                </div>
                <div>
                  <div className={`text-sm font-bold ${txt}`}>{a.title}</div>
                  <div className={`text-[11px] ${muted}`}>{a.desc}</div>
                </div>
                <ChevronRight className={`w-4 h-4 ml-auto shrink-0 ${muted}`} />
              </button>
            );
          })}
        </div>

      </div>
    </div>
  );
};
