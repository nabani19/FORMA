// 🤖 OpenRouter AI Vision Integration Engine for TRACker

const OPENROUTER_API_KEY = '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';
const OPENROUTER_ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

export interface OpenRouterFoodAnalysis {
  name: string;
  category: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodiumMg: number;
  servingSize: string;
  priceInr: number;
  healthScore: number;
  glycemicIndex: number;
  sugarSpikeRisk: 'Low' | 'Moderate' | 'High';
  qualityScore: string;
  processingLevel: 'Whole Food' | 'Minimally Processed' | 'Processed' | 'Ultra-Processed';
  ingredients: string[];
  vitaminCMg?: number;
  calciumMg?: number;
  ironMg?: number;
  potassiumMg?: number;
  magnesiumMg?: number;
  allergens?: string[];
  dietaryFlags?: string[];
  cookingMethod?: string;
}

export async function analyzeFoodImageWithOpenRouter(
  imageBase64: string,
  modelId: string = 'google/gemini-2.0-flash-001'
): Promise<OpenRouterFoodAnalysis | null> {
  try {
    const prompt = `You are a world-class AI Nutritionist and Food Vision Scientist. Analyze this food image and return a JSON object ONLY adhering strictly to the following schema:
{
  "name": "Exact Name of Food / Dish",
  "category": "Food Category (e.g. High Protein, Grain, Salad)",
  "calories": 480,
  "protein": 32,
  "carbs": 45,
  "fat": 16,
  "fiber": 7,
  "sugar": 4,
  "sodiumMg": 360,
  "servingSize": "1 Serving (350g)",
  "priceInr": 90,
  "healthScore": 94,
  "glycemicIndex": 38,
  "sugarSpikeRisk": "Low",
  "qualityScore": "Excellent",
  "processingLevel": "Whole Food",
  "ingredients": ["Main Ingredient 1", "Ingredient 2", "Ingredient 3"],
  "vitaminCMg": 24,
  "calciumMg": 110,
  "ironMg": 3.4,
  "potassiumMg": 450,
  "magnesiumMg": 65,
  "allergens": ["Dairy"],
  "dietaryFlags": ["High Protein", "Gluten-Free"],
  "cookingMethod": "Grilled / Sautéed"
}
Ensure numeric values are realistic estimations for the food in the image. Do not include markdown code block quotes or text outside the JSON.`;

    const formattedImage = imageBase64.startsWith('data:')
      ? imageBase64
      : `data:image/jpeg;base64,${imageBase64}`;

    const response = await fetch(OPENROUTER_ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://tracker-app-ai.vercel.app/',
        'X-Title': 'TRACker AI Food Scanner Engine',
      },
      body: JSON.stringify({
        model: modelId,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              { type: 'image_url', image_url: { url: formattedImage } },
            ],
          },
        ],
        temperature: 0.1,
      }),
    });

    if (!response.ok) {
      console.warn('OpenRouter API response status:', response.status);
      // Fall back to gemini-2.0-flash if primary model fails
      if (modelId !== 'google/gemini-2.0-flash-001') {
        return analyzeFoodImageWithOpenRouter(imageBase64, 'google/gemini-2.0-flash-001');
      }
      return null;
    }

    const data = await response.json();
    const rawText = data?.choices?.[0]?.message?.content || '';

    // Extract valid JSON substring
    const match = rawText.match(/\{[\s\S]*\}/);
    if (!match) return null;

    const parsed: OpenRouterFoodAnalysis = JSON.parse(match[0]);
    return parsed;
  } catch (error) {
    console.error('OpenRouter Vision Analysis exception:', error);
    return null;
  }
}
