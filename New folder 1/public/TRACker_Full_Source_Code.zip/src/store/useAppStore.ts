import { create } from 'zustand';
import { UserProfile, MacroGoals, LoggedMeal, FoodItem } from '../types';

interface AppState {
  // Auth & Profile State
  isAuthenticated: boolean;
  userProfile: UserProfile;
  macroGoals: MacroGoals;
  activeTab: 'dashboard' | 'meals' | 'scanner' | 'analytics' | 'profile';
  isDarkMode: boolean;

  // Daily Tracking State
  loggedMeals: LoggedMeal[];
  waterIntakeLiters: number;
  streakDays: number;

  // Scanner history
  scannedFoods: FoodItem[];

  // Actions
  login: (email: string, name: string) => void;
  logout: () => void;
  updateProfile: (profile: Partial<UserProfile>) => void;
  recalculateMacros: () => void;
  setActiveTab: (tab: AppState['activeTab']) => void;
  toggleTheme: () => void;

  addLoggedMeal: (food: FoodItem, servings: number, mealType: LoggedMeal['mealType']) => void;
  removeLoggedMeal: (id: string) => void;

  addWater: (amountLiters: number) => void;
  setWater: (liters: number) => void;
  setWaterGoal: (targetLiters: number) => void;
  addScannedFood: (food: FoodItem) => void;
}

const defaultProfile: UserProfile = {
  name: 'User',
  email: 'user@tracker.ai',
  age: 28,
  gender: 'male',
  heightCm: 180,
  weightKg: 78,
  activityLevel: 'moderate',
  goal: 'fat_loss',
  dietaryPreference: 'high_protein',
  dailyBudgetInr: 66,
  monthlyBudgetInr: 2000,
  subscriptionPlan: 'pro',
  allergies: ['Peanuts'],
};

// Format currency helper
export function formatInr(amount: number): string {
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

// Calculate TDEE & Macro goals using Mifflin-St Jeor Formula
export function calculateMacros(profile: UserProfile): MacroGoals {
  const weight = Math.max(10, Number(profile.weightKg) || 70);
  const height = Math.max(50, Number(profile.heightCm) || 170);
  const age = Math.max(12, Number(profile.age) || 25);

  let bmr = 10 * weight + 6.25 * height - 5 * age;
  bmr += profile.gender === 'male' ? 5 : -161;

  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    extreme: 1.9,
  };

  let tdee = bmr * (activityMultipliers[profile.activityLevel] || 1.55);

  if (profile.goal === 'fat_loss') {
    tdee -= 500;
  } else if (profile.goal === 'muscle_gain') {
    tdee += 350;
  }

  const calories = Math.max(1000, Math.round(tdee));

  let pRatio = 0.30, cRatio = 0.40, fRatio = 0.30;
  if (profile.dietaryPreference === 'keto') {
    pRatio = 0.25; cRatio = 0.05; fRatio = 0.70;
  } else if (profile.dietaryPreference === 'vegan') {
    pRatio = 0.25; cRatio = 0.50; fRatio = 0.25;
  }

  const proteinGrams = Math.round((calories * pRatio) / 4);
  const carbsGrams = Math.round((calories * cRatio) / 4);
  const fatGrams = Math.round((calories * fRatio) / 9);
  const waterLiters = Number((weight * 0.035).toFixed(1));

  return { calories, proteinGrams, carbsGrams, fatGrams, waterLiters };
}

const initialMockMeals: LoggedMeal[] = [
  {
    id: 'meal-1',
    foodItem: {
      id: 'f1',
      name: 'Grilled Chicken Breast Bowl with Quinoa & Avocado',
      category: 'Lean Protein',
      calories: 520,
      protein: 48,
      carbs: 42,
      fat: 16,
      fiber: 7,
      sugar: 2,
      sodiumMg: 380,
      servingSize: '1 Bowl (350g)',
      priceInr: 120,
      healthScore: 94,
      allergens: [],
      dietaryFlags: ['High Protein', 'Gluten-Free'],
    },
    servings: 1,
    mealType: 'lunch',
    timestamp: '12:30 PM',
  },
  {
    id: 'meal-2',
    foodItem: {
      id: 'f2',
      name: 'Greek Yogurt with Mixed Berries & Almonds',
      category: 'Dairy & Fruit',
      calories: 280,
      protein: 22,
      carbs: 26,
      fat: 9,
      fiber: 4,
      sugar: 14,
      sodiumMg: 95,
      servingSize: '1 Cup (220g)',
      priceInr: 60,
      healthScore: 90,
      allergens: ['Tree Nuts', 'Dairy'],
      dietaryFlags: ['High Calcium', 'Vegetarian'],
    },
    servings: 1,
    mealType: 'breakfast',
    timestamp: '08:15 AM',
  }
];

export const useAppStore = create<AppState>((set, get) => ({
  isAuthenticated: true,
  userProfile: defaultProfile,
  macroGoals: calculateMacros(defaultProfile),
  activeTab: 'dashboard',
  isDarkMode: true,

  loggedMeals: initialMockMeals,
  waterIntakeLiters: 1.8,
  streakDays: 7,
  scannedFoods: [],

  login: (email, name) => {
    set((state) => ({
      isAuthenticated: true,
      userProfile: { ...state.userProfile, email, name },
    }));
  },

  logout: () => {
    set({ isAuthenticated: false });
  },

  updateProfile: (updatedFields) => {
    set((state) => {
      const newProfile = { ...state.userProfile, ...updatedFields };
      const newMacros = calculateMacros(newProfile);
      return { userProfile: newProfile, macroGoals: newMacros };
    });
  },

  recalculateMacros: () => {
    set((state) => ({
      macroGoals: calculateMacros(state.userProfile),
    }));
  },

  setActiveTab: (tab) => set({ activeTab: tab }),

  toggleTheme: () => {
    set((state) => {
      const newDark = !state.isDarkMode;
      if (newDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return { isDarkMode: newDark };
    });
  },

  addLoggedMeal: (foodItem, servings, mealType) => {
    const newMeal: LoggedMeal = {
      id: `meal-${Date.now()}`,
      foodItem,
      servings,
      mealType,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    set((state) => ({ loggedMeals: [newMeal, ...state.loggedMeals] }));
  },

  removeLoggedMeal: (id) => {
    set((state) => ({ loggedMeals: state.loggedMeals.filter(m => m.id !== id) }));
  },

  addWater: (amountLiters) => {
    set((state) => ({
      waterIntakeLiters: Math.max(0, Number((state.waterIntakeLiters + amountLiters).toFixed(1))),
    }));
  },

  setWater: (liters) => {
    set({ waterIntakeLiters: Math.max(0, Number(liters.toFixed(1))) });
  },

  setWaterGoal: (targetLiters) => {
    set((state) => ({
      macroGoals: {
        ...state.macroGoals,
        waterLiters: Math.max(1, Number(targetLiters.toFixed(1))),
      },
    }));
  },

  addScannedFood: (food: FoodItem) => {
    set((state) => ({ scannedFoods: [food, ...state.scannedFoods.slice(0, 19)] }));
  },
}));
