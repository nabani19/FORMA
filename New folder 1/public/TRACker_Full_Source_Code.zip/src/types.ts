export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'extreme';
export type FitnessGoal = 'fat_loss' | 'muscle_gain' | 'maintenance';
export type DietaryPreference = 'standard' | 'keto' | 'vegan' | 'high_protein' | 'intermittent_fasting';
export type SubscriptionPlan = 'free' | 'pro' | 'elite';

export interface UserProfile {
  name: string;
  email: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: FitnessGoal;
  dietaryPreference: DietaryPreference;
  dailyBudgetInr: number;
  monthlyBudgetInr?: number;
  subscriptionPlan: SubscriptionPlan;
  allergies: string[];
}

export interface MacroGoals {
  calories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatGrams: number;
  waterLiters: number;
}

export interface FoodItem {
  id: string;
  name: string;
  category: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodiumMg: number;
  potassiumMg?: number;
  calciumMg?: number;
  ironMg?: number;
  vitaminCMg?: number;
  glycemicIndex?: number; // 0 to 100
  sugarSpikeRisk?: 'Low' | 'Moderate' | 'High';
  servingSize: string;
  priceInr: number;
  imageUrl?: string;
  allergens?: string[];
  dietaryFlags?: string[];
  healthScore: number; // 1 to 100
  substitutions?: string[];
}

export interface LoggedMeal {
  id: string;
  foodItem: FoodItem;
  servings: number;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  timestamp: string;
}

export interface AIVisionModel {
  id: string;
  name: string;
  badge: string;
  description: string;
  latencyMs: number;
  accuracyPercent: number;
  architecture: string;
  isOfflineCapable: boolean;
}
